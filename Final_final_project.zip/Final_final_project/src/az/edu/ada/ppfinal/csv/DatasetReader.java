package az.edu.ada.ppfinal.csv;

import az.edu.ada.ppfinal.model.Field;
import az.edu.ada.ppfinal.pojo.PlaneCrash;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;

public interface DatasetReader<T> {
    void read() throws IOException;

    List<T> list();

    List<T> filter(Predicate<T> filter);

    List<PlaneCrash> sort(Field field, boolean asc);

    List<PlaneCrash> search(Field field, Scanner scan);

    List<String> getColumns();
}