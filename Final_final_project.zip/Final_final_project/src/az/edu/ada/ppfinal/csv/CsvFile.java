package az.edu.ada.ppfinal.csv;

import az.edu.ada.ppfinal.exception.EmptyDatasetException;
import az.edu.ada.ppfinal.model.Field;
import az.edu.ada.ppfinal.pojo.PlaneCrash;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.function.Predicate;
import java.util.stream.Collectors;



import java.io.FileReader;
import java.io.IOException;
import java.util.Arrays;
import java.util.List;

/**
 * CSV file representation
 */

public class CsvFile implements DatasetReader<PlaneCrash> {
    private final List<PlaneCrash> crashes = new ArrayList<>();

    private final Path path;

    private final List<String> columns = new ArrayList<>();

    /**
     * @param path Path to file
     */
    public CsvFile(Path path) throws IOException {
        this.path = path;
        read();
    }

    @Override
    public void read() throws IOException {
        List<String[]> r = null;

        try (CSVReader reader = new CSVReader(new FileReader(String.valueOf(path)))) {
            r = reader.readAll();
        } catch (CsvException e) {
            e.printStackTrace();
        }

        List<String> lines = Files.readAllLines(path);
        String firstLine = lines.remove(0);
        columns.addAll(Arrays.asList(firstLine.split(",")));

        r.remove(0);
        for (String[] arrays : r) {
            crashes.add(new PlaneCrash(arrays));
        }
    }

    @Override
    public List<PlaneCrash> list() {
        if (crashes.isEmpty()) {
            throw new EmptyDatasetException();
        }

        return crashes;
    }

    @Override
    public List<PlaneCrash> filter(Predicate<PlaneCrash> filter) {
        if (crashes.isEmpty()) {
            throw new EmptyDatasetException();
        }

        return crashes.stream().filter(filter).collect(Collectors.toList());
    }

    @Override
    public List<PlaneCrash> sort(Field field, boolean asc) {
        return crashes.stream().sorted((o1, o2) -> field.compare(o1, o2, asc))
                .collect(Collectors.toList());
    }

   
    @Override
    public List<String> getColumns() {
        return columns;
    }

}
