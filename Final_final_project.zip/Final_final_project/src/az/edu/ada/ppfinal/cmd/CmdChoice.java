package az.edu.ada.ppfinal.cmd;

import az.edu.ada.ppfinal.csv.CsvFile;
import az.edu.ada.ppfinal.model.Action;
import az.edu.ada.ppfinal.model.Field;
import az.edu.ada.ppfinal.model.Filter;
import az.edu.ada.ppfinal.pojo.PlaneCrash;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 * NOTE: It is not stream overuse here, I believe it is much simpler to do so.
 *
 */

public class CmdChoice implements Runnable {

    private final CsvFile file;

    public CmdChoice(CsvFile file) {
        this.file = file;
    }

    @Override
    public void run() {
        while (true) {
            System.out.println("=== SELECT ACTION ===");
            System.out.println("1 - List all entities");
            System.out.println("2 - Sort entities");
            System.out.println("3 - Search entities");
            System.out.println("4 - List columns");
            System.out.println("5 - Filter entities");
            System.out.println("6 - End programm");
            Scanner scan = new Scanner(System.in);

            Action action = Action.getByIndex(scan.nextInt());

            if (action == null) {
                printDefaultActions();
                continue;
            }

            if (action == Action.END) {
                break;
            }

            processAction(action, scan);
        }
    }

    private void processAction(Action action, Scanner scanner) {
        action.printHelp();

        switch (action) {
            case LIST_ALL:
              
                file.list().forEach(p -> System.out.println(p.toString()));
                break;
            case SORT:
               
                Field sortField = requestField(action, scanner);

                System.out.println("Enter 1 for ascending or any other number for descending");

                boolean ascending = scanner.nextInt() == 1;

                file.list().stream()
                        .sorted((o1, o2) -> sortField.compare(o1, o2, ascending))
                        .forEach(System.out::println);
                break;
            case SEARCH:
               
                Field searchField = requestField(action, scanner);
                processSearch(searchField, scanner);
                break;
            case LIST_COLUMNS:
           
                file.getColumns().forEach(System.out::println);
                break;
            case FILTER:
             
                Field filterField = requestField(action, scanner);

                filter(filterField, scanner);
                break;
        }
    }

    private void processSearch(Field field, Scanner scan) {
        switch (field) {
            case DATE:
                LocalDate date = requestDate(scan);

                System.out.println("Found results: ");
                file.list().stream().filter(c -> c.getDate().isEqual(date)).forEach(System.out::println);
                break;
            case TIME:
                LocalTime time = requestTime(scan);

                System.out.println("Found results: ");
                file.list().stream().filter(c -> c.getTime().compareTo(time) == 0).forEach(System.out::println);
                break;
            case LOCATION:
                scan.nextLine();
                System.out.println("Enter location: ");
                String location = scan.nextLine();

                file.filter(c -> c.getLocation().contains(location)).forEach(System.out::println);
                break;
            case OPERATOR:
                scan.nextLine();
                System.out.println("Enter operator: ");
                String operator = scan.nextLine();

                file.filter(c -> c.getOperator().contains(operator)).forEach(System.out::println);
                break;
            case FLIGHT:
                scan.nextLine();
                System.out.println("Enter flight: ");
                String flight = scan.nextLine();

                file.filter(c -> c.getFlight().contains(flight)).forEach(System.out::println);
                break;
            case ROUTE:
                scan.nextLine();
                System.out.println("Enter route: ");
                String route = scan.nextLine();

                file.filter(c -> c.getRoute().contains(route)).forEach(System.out::println);
                break;
            case TYPE:
                scan.nextLine();
                System.out.println("Enter type: ");
                String type = scan.nextLine();

                file.filter(c -> c.getType().contains(type)).forEach(System.out::println);
                break;
            case REGISTRATION:
                scan.nextLine();
                System.out.println("Enter registration: ");
                String reg = scan.nextLine();

                file.filter(c -> c.getRegistration().contains(reg)).forEach(System.out::println);
                break;
            case IN:
                scan.nextLine();
                System.out.println("Enter cn.In: ");
                String in = scan.nextLine();

                file.filter(c -> c.getIn().contains(in)).forEach(System.out::println);
                break;
            case ABOARD:
                scan.nextLine();
                System.out.println("Enter abroad: ");
                int aboard = scan.nextInt();

                file.filter(c -> c.getAboard() == aboard).forEach(System.out::println);
                break;
            case FATALITIES:
                scan.nextLine();
                System.out.println("Enter fatalities: ");
                int fatalities = scan.nextInt();

                file.filter(c -> c.getFatalities() == fatalities).forEach(System.out::println);
                break;
            case GROUND:
                scan.nextLine();
                System.out.println("Enter ground: ");
                int ground = scan.nextInt();

                file.filter(c -> c.getGround() == ground).forEach(System.out::println);
                break;
            case SURVIVORS:
                scan.nextLine();
                System.out.println("Enter survivors: ");
                int surv = scan.nextInt();

                file.filter(c -> c.getSurvivors() == surv).forEach(System.out::println);
                break;
            case SURVIVAL_RATE:
                scan.nextLine();
                System.out.println("Enter survival rate: ");
                double rate = scan.nextDouble();

                file.filter(c -> c.getSurvivalRate() == rate).forEach(System.out::println);
                break;
            case SUMMARY:
                scan.nextLine();
                System.out.println("Enter summary: ");
                String text = scan.nextLine();

                file.filter(c -> c.getSummary().contains(text)).forEach(System.out::println);
                break;
        }
    }

    private void filter(Field field, Scanner scanner) {
        if (field.getType() == Field.DataType.NUMERIC) {
            System.out.println("1 -Equal (eq)");
            System.out.println("2- Greater than (gt)");
            System.out.println("3 - Less than (lt)");
            System.out.println("4 - Greater and equal to (ge)");
            System.out.println("5 - Less and equal to (le)");
            System.out.println("6 - Between (bt)");
            System.out.println("7 - null");
        } else if (field.getType() == Field.DataType.STRING) {
            System.out.println("1 - starts with");
            System.out.println("2 - ends with");
            System.out.println("3 - contains");
            System.out.println("4 - null");;
        } else  {
            System.out.println("1 - specific year");
            System.out.println("2 - specific month");
            System.out.println("3 - specific day");
        }

        int action = scanner.nextInt();

        switch (field) {
            case DATE:
                processDateFilter(Filter.ChronicField.getByIndex(action), scanner)
                        .forEach(System.out::println);
                break;
            case TIME:
                processTimeFilter(Filter.ChronicField.getByIndex(action), scanner)
                        .forEach(System.out::println);
                break;
            case LOCATION:
            	processTimeFilter(Filter.ChronicField.getByIndex(action), scanner)
                .forEach(System.out::println);
            case OPERATOR:
            	processTimeFilter(Filter.ChronicField.getByIndex(action), scanner)
                .forEach(System.out::println);
            case FLIGHT:
            	processTimeFilter(Filter.ChronicField.getByIndex(action), scanner)
                .forEach(System.out::println);
            case ROUTE:
            	processTimeFilter(Filter.ChronicField.getByIndex(action), scanner)
                .forEach(System.out::println);
            case TYPE:
            	processTimeFilter(Filter.ChronicField.getByIndex(action), scanner)
                .forEach(System.out::println);
            case REGISTRATION:
            	processTimeFilter(Filter.ChronicField.getByIndex(action), scanner)
                .forEach(System.out::println);
            case IN:
            	processTimeFilter(Filter.ChronicField.getByIndex(action), scanner)
                .forEach(System.out::println);
            case SUMMARY:
                processStringFilter(field, Filter.StringField.getByIndex(action), scanner)
                        .forEach(System.out::println);
            case ABOARD:
            	processTimeFilter(Filter.ChronicField.getByIndex(action), scanner)
                .forEach(System.out::println);
            case FATALITIES:
            	processTimeFilter(Filter.ChronicField.getByIndex(action), scanner)
                .forEach(System.out::println);
            case GROUND:
            	processTimeFilter(Filter.ChronicField.getByIndex(action), scanner)
                .forEach(System.out::println);
            case SURVIVORS:
            	processTimeFilter(Filter.ChronicField.getByIndex(action), scanner)
                .forEach(System.out::println);
            case SURVIVAL_RATE:
                processNumericFilter(field, Filter.NumericField.getByIndex(action), scanner)
                        .forEach(System.out::println);
        }
    }

    private List<PlaneCrash> processDateFilter(Filter.ChronicField filter, Scanner scan) {
        switch (filter) {
            case EQUAL:
                LocalDate date = requestDate(scan);
                return file.filter(c -> c.getDate().isEqual(date));
            case GREATER_THAN:
                LocalDate greaterThanDate = requestDate(scan);
                return file.filter(c -> c.getDate().isAfter(greaterThanDate));
            case LESS_THAN:
                LocalDate lessThanDate = requestDate(scan);
                return file.filter(c -> c.getDate().isBefore(lessThanDate));
            case GREATER_AND_EQUAL:
                LocalDate greaterThanDateEq = requestDate(scan);
                return file.filter(c -> c.getDate().isAfter(greaterThanDateEq) || c.getDate().isEqual(greaterThanDateEq));
            case LESS_AND_EQUAL:
                LocalDate lessThanDateEq = requestDate(scan);
                return file.filter(c -> c.getDate().isBefore(lessThanDateEq) || c.getDate().isEqual(lessThanDateEq));
            case BETWEEN:
                LocalDate from = requestDate(scan);
                LocalDate to = requestDate(scan);
                return file.filter(c -> c.getDate().isBefore(from) && c.getDate().isAfter(to));
            case NULL:
                return file.filter(c -> c.getDate() == null);
            case SPECIFIC_YEAR:
                int year = scan.nextInt();
                return file.filter(c -> c.getDate().getYear() == year);
            case SPECIFIC_MONTH:
                int month =  scan.nextInt();
                return file.filter(c -> c.getDate().getMonthValue() == month);
            case SPECIFIC_DAY:
                int day = scan.nextInt();
                return file.filter(c -> c.getDate().getDayOfMonth() == day);
        }

        return Collections.emptyList();
    }

    private List<PlaneCrash> processTimeFilter(Filter.ChronicField filter, Scanner scan) {
        switch (filter) {
            case EQUAL:
                LocalTime time = requestTime(scan);
                return file.filter(c -> c.getTime().compareTo(time) == 0);
            case GREATER_THAN:
                LocalTime greater = requestTime(scan);
                return file.filter(c -> c.getTime().compareTo(greater) > 0);
            case LESS_THAN:
                LocalTime less = requestTime(scan);
                return file.filter(c -> c.getTime().compareTo(less) < 0);
            case GREATER_AND_EQUAL:
                LocalTime greaterEq = requestTime(scan);
                return file.filter(c -> c.getTime().compareTo(greaterEq) >= 0);
            case LESS_AND_EQUAL:
                LocalTime lessEq = requestTime(scan);
                return file.filter(c -> c.getTime().compareTo(lessEq) <= 0);
            case BETWEEN:
                LocalTime from = requestTime(scan);
                LocalTime to = requestTime(scan);

                return file.filter(c -> c.getTime().isAfter(to) && c.getTime().isBefore(from));
            case NULL:
                return file.filter(c -> c.getTime() == null);
        }

        return Collections.emptyList();
    }

    private List<PlaneCrash> processStringFilter(Field field, Filter.StringField filter, Scanner scan) {
        String in = scan.nextLine();

        switch (field) {
            case LOCATION:
                return file.filter(c -> filter.apply(in, c.getLocation()));
            case OPERATOR:
                return file.filter(c -> filter.apply(in, c.getOperator()));
            case FLIGHT:
                return file.filter(c -> filter.apply(in, c.getFlight()));
            case ROUTE:
                return file.filter(c -> filter.apply(in, c.getRoute()));
            case TYPE:
                return file.filter(c -> filter.apply(in, c.getType()));
            case REGISTRATION:
                return file.filter(c -> filter.apply(in, c.getRegistration()));
            case IN:
                return file.filter(c -> filter.apply(in, c.getIn()));
            case SUMMARY:
                return file.filter(c -> filter.apply(in, c.getSummary()));
            default:
                return Collections.emptyList();
        }
    }

    private List<PlaneCrash> processNumericFilter(Field field, Filter.NumericField filter, Scanner scan) {
        if (field == Field.SURVIVAL_RATE) {
            double in = scan.nextDouble();

            return file.filter(c -> filter.applyDouble(in, c.getSurvivalRate()));
        }
        else if(field == Field.ABOARD) {
            double in = scan.nextDouble();
            return file.filter(c -> filter.applyDouble(in, c.getAboard()));
        }
        int in = scan.nextInt();

        switch (field) {
            case FATALITIES:
                return file.filter(c -> filter.apply(in, c.getFatalities()));
            case GROUND:
                return file.filter(c -> filter.apply(in, c.getGround()));
            case SURVIVORS:
                return file.filter(c -> filter.apply(in, c.getSurvivors()));
            default:
                return Collections.emptyList();
        }
    }

    private LocalDate requestDate(Scanner scan) {
        scan.nextLine();
        System.out.println("Enter date in format day/month/year");

        String date = scan.nextLine();

        try {
            return LocalDate.parse(date, PlaneCrash.getDateFormatter());
        } catch (DateTimeParseException e) {
            System.out.printf("Wrong format! Expected String in day/month/year format, got %s%n", date);
            return requestDate(scan);
        }
    }

    private LocalTime requestTime(Scanner scan) {
        scan.nextLine();
        System.out.println("Enter time in format hours:minutes");

        String time = scan.nextLine();

        try {
            return LocalTime.parse(time, PlaneCrash.getTimeFormatter());
        } catch (DateTimeParseException e) {
            System.out.printf("Wrong format! Expected String in hours:month format, got %s%n", time);
            return requestTime(scan);
        }
    }

    private void printDefaultActions() {
        System.out.println("=== SELECT ACTION ===");
        System.out.println("1 - List all entities");
        System.out.println("2 - Sort entities");
        System.out.println("3 - Search entities");
        System.out.println("4 - List columns");
        System.out.println("5 - Filter entities");
        System.out.println("6 - End programm");
    }

    private Field requestField(Action action, Scanner scan) {
        Field field = Field.getByIndex(scan.nextInt());

        if (field == null) {
            System.out.println("Err, bad index");
            action.printHelp();

            return requestField(action, scan);
        }

        return field;
    }
}
