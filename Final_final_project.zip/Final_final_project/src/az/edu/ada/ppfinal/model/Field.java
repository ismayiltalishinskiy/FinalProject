package az.edu.ada.ppfinal.model;

import az.edu.ada.ppfinal.pojo.PlaneCrash;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public enum Field {
    DATE(DataType.CHRONIC, 1) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            return (asc) ? first.getDate().compareTo(second.getDate()) : second.getDate().compareTo(first.getDate());
        }
    },

    TIME(DataType.CHRONIC, 2) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            if(first.getTime() == null)
            {
                return -1;
            }
            else if(second.getTime() == null)
            {
                return 1;
            }
            else {
                return (asc) ? first.getTime().compareTo(second.getTime()) : second.getTime().compareTo(first.getTime());
            }
        }

    },

    LOCATION(DataType.STRING, 3) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            return (asc) ? first.getLocation().compareTo(second.getLocation()) : second.getLocation().compareTo(first.getLocation());
        }
    },

    OPERATOR(DataType.STRING, 4) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            return (asc) ? first.getOperator().compareTo(second.getOperator()) : second.getOperator().compareTo(first.getOperator());
        }
    },

    FLIGHT(DataType.STRING, 5) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            return (asc) ? first.getFlight().compareTo(second.getFlight()) : second.getFlight().compareTo(first.getFlight());
        }
    },

    ROUTE(DataType.STRING, 6) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            return (asc) ? first.getRoute().compareTo(second.getRoute()) : second.getRoute().compareTo(first.getRoute());
        }
    },

    TYPE(DataType.STRING, 7) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            return (asc) ? first.getType().compareTo(second.getType()) : second.getType().compareTo(first.getType());
        }
    },

    REGISTRATION(DataType.STRING, 8) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            return (asc) ? first.getRegistration().compareTo(second.getRegistration()) : second.getRegistration().compareTo(first.getRegistration());
        }
    },

    IN(DataType.STRING, 9) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            return (asc) ? first.getIn().compareTo(second.getIn()) : second.getIn().compareTo(first.getIn());
        }
    },

    ABOARD(DataType.NUMERIC, 10) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            return (asc) ? Double.compare(first.getAboard(), second.getAboard()) : Double.compare(second.getAboard(), first.getAboard());
        }
    },

    FATALITIES(DataType.NUMERIC, 11) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            return (asc) ? Integer.compare(first.getFatalities(), second.getFatalities()) : Integer.compare(second.getFatalities(), first.getFatalities());
        }
    },

    GROUND(DataType.NUMERIC, 12) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            return (asc) ? Integer.compare(first.getGround(), second.getGround()) : Integer.compare(second.getGround(), first.getGround());
        }
    },

    SURVIVORS(DataType.NUMERIC, 13) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            return (asc) ? Integer.compare(first.getSurvivors(), second.getSurvivors()) : Integer.compare(second.getSurvivors(), first.getSurvivors());
        }
    },

    SURVIVAL_RATE(DataType.NUMERIC, 14) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            return (asc) ? Double.compare(first.getSurvivalRate(), second.getSurvivalRate()) : Double.compare(second.getSurvivalRate(), first.getSurvivalRate());
        }
    },

    SUMMARY(DataType.STRING, 15) {
        @Override
        public int compare(PlaneCrash first, PlaneCrash second, boolean asc) {
            return (asc) ? first.getSummary().compareTo(second.getSummary()) : second.getSummary().compareTo(first.getSummary());
        }
    };

    final DataType type;
    final int i;

    Field(DataType type, int i) {
        this.type = type;
        this.i = i;
    }

    public DataType getType() {
        return type;
    }

    public abstract int compare(PlaneCrash first, PlaneCrash second, boolean asc);

    public static Field getByIndex(int i) {
        return Arrays.stream(values()).filter(c -> c.i == i).findFirst().orElse(null);
    }

    public static List<Field> getStringFields() {
        return Arrays.stream(values()).filter(f -> f.getType() == DataType.STRING).collect(Collectors.toList());
    }

    public enum DataType {
        STRING,
        CHRONIC,
        NUMERIC
    }

}