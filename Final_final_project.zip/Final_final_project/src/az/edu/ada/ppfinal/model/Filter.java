package az.edu.ada.ppfinal.model;

import java.util.Arrays;

public enum Filter {;
    public enum StringField {
        STARTS_WITH(1) {
            @Override
            public boolean apply(String in, String value) {
                return value.startsWith(in);
            }
        },

        ENDS_WITH(2) {
            @Override
            public boolean apply(String in, String value) {
                return value.endsWith(in);
            }
        },
        CONTAINS(3) {
            @Override
            public boolean apply(String in, String value) {
                return value.contains(in);
            }
        },
        NULL(4) {
            @Override
            public boolean apply(String in, String value) {
                return value == null;
            }
        };

        final int i;

        StringField(int i) {
            this.i = i;
        }

        public abstract boolean apply(String in, String value);

        public static StringField getByIndex(int i) {
            return Arrays.stream(values()).filter(f -> f.i == i).findFirst().orElse(null);
        }
    }

    public enum NumericField {
        EQUAL(1) {
            @Override
            public boolean apply(int in, int value) {
                return in == value;
            }

            @Override
            public boolean applyDouble(double in, double value) {
                return value == in;
            }
        },
        GREATER_THAN(2) {
            @Override
            public boolean apply(int in, int value) {
                return value > in;
            }

            @Override
            public boolean applyDouble(double in, double value) {
                return value > in;
            }
        },
        LESS_THAN(3) {
            @Override
            public boolean apply(int in, int value) {
                return value < in;
            }

            @Override
            public boolean applyDouble(double in, double value) {
                return value < in;
            }
        },
        GREATER_AND_EQUAL(4) {
            @Override
            public boolean apply(int in, int value) {
                return value >= in;
            }

            @Override
            public boolean applyDouble(double in, double value) {
                return value >= in;
            }
        },
        LESS_AND_EQUAL(5) {
            @Override
            public boolean apply(int in, int value) {
                return value <= in;
            }

            @Override
            public boolean applyDouble(double in, double value) {
                return false;
            }
        },
        NULL(6) {
            @Override
            public boolean apply(int in, int value) {
                return value == 0;
            }

            @Override
            public boolean applyDouble(double in, double value) {
                return value == 0;
            }
        };

        final int i;

        NumericField(int i) {
            this.i = i;
        }

        public abstract boolean apply(int in, int value);

        public abstract boolean applyDouble(double in, double value);

        public static NumericField getByIndex(int i) {
            return Arrays.stream(values()).filter(f -> f.i == i).findFirst().orElse(null);
        }

    }

    public enum ChronicField {
        EQUAL(1),
        GREATER_THAN(2),
        LESS_THAN(3),
        GREATER_AND_EQUAL(4),
        LESS_AND_EQUAL(5),
        BETWEEN(6),
        NULL(7),
        SPECIFIC_YEAR(8),
        SPECIFIC_MONTH(9),
        SPECIFIC_DAY(10);

        final int i;

        ChronicField(int i) {
            this.i = i;
        }

        public static ChronicField getByIndex(int i) {
            return Arrays.stream(values()).filter(f -> f.i == i).findFirst().orElse(null);
        }
    }
}
