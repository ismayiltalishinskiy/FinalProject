package az.edu.ada.ppfinal.model;

import java.util.Arrays;

public enum Action {
    LIST_ALL(1) {
        @Override
        public void printHelp() {
            //nothing to expect
        }
    },
    SORT(2) {
        @Override
        public void printHelp() {
            System.out.println("Enter index of field by which you want to sort");
            System.out.println("1 - DATE | 2 - TIME | 3 - LOCATION | 4 - OPERATOR | 5 - ROUTE | 6 - TYPE | 7 - REGISTRATION | 8 - IN | 9 - ABOARD | 10 - FATALITIES | 11 - GROUND | 12 - SURVIVORS | 13 - SURVIVOR_RATE");
            //System.out.println("1 - DATE | 2 - TIME");
        }
    },
    SEARCH(3) {
        @Override
        public void printHelp() {
        System.out.println("Enter index of field which you want to search");
        System.out.println("1 - DATE | 2 - TIME | 3 - LOCATION | 4 - OPERATOR | 5 - ROUTE | 6 - TYPE | 7 - REGISTRATION | 8 - IN | 9 - ABOARD | 10 - FATALITIES | 11 - GROUND | 12 - SURVIVORS | 13 - SURVIVOR_RATE");
        
        }
    },
    LIST_COLUMNS(4) {
        @Override
        public void printHelp() {
        	
        }
    },
    FILTER(5) {
        @Override
        public void printHelp() {
        System.out.println("Enter the index of field by which you want to filer");
        System.out.println("1 - DATE | 2 - TIME | 3 - LOCATION | 4 - OPERATOR | 5 - ROUTE | 6 - TYPE | 7 - REGISTRATION | 8 - IN | 9 - ABOARD | 10 - FATALITIES | 11 - GROUND | 12 - SURVIVORS | 13 - SURVIVOR_RATE");
        }
    },

    END(6) {
        @Override
        public void printHelp() {
            System.out.println("Ok, bye");
        }
    };

    final int i;

    Action(int i) {
        this.i = i;
    }

    public int getI() {
        return i;
    }

    public abstract void printHelp();

    public static Action getByIndex(int i) {
        return Arrays.stream(values()).filter(action -> action.getI() == i).findFirst().orElse(null);
    }
}
