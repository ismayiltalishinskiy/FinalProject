package az.edu.ada.ppfinal.exception;

public class EmptyDatasetException extends RuntimeException {

}
