package az.edu.ada.ppfinal.pojo;


import java.lang.reflect.Field;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Arrays;
import java.util.stream.Collectors;

public final class PlaneCrash {

    private final LocalDate date;
    private final LocalTime time;

    private final String location, operator, flight, route, type, registration, in;

    private final int fatalities, ground, survivors;

    private final double aboard, survivalRate;

    private final String summary;

    public PlaneCrash(String[] split) {
        if (split.length < 15) {
            throw new IllegalArgumentException("Wrong data format");
        }
        split = s.split("(?<=,|^)([^,]*)(,\\1)+(?=,|$)");
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("M/d/yy");
        LocalDate tmp = LocalDate.parse(split[0], formatter);
        this.date = tmp.minusYears(100);
        formatter = DateTimeFormatter.ofPattern("H:mm");
        this.time = StringUtils.isNotBlank(split[1]) ? LocalTime.parse(split[1], formatter) : null;
        this.location = split[2];
        this.operator = split[3];
        this.flight = split[4];
        this.route = split[5];
        this.type = split[6];
        this.registration = split[7];
        this.in = split[8];

        this.aboard = Double.parseDouble(split[9]);
        this.fatalities = Integer.parseInt(split[10]);
        this.ground = Integer.parseInt(split[11]);
        this.survivors = Integer.parseInt(split[12]);
        this.survivalRate = Double.parseDouble(split[13]);

        this.summary = split[14];
    }


    public LocalDate getDate() {
        return date;
    }

    public LocalTime getTime() {
        return time;
    }

    public String getLocation() {
        return location;
    }

    public String getOperator() {
        return operator;
    }

    public String getFlight() {
        return flight;
    }

    public String getRoute() {
        return route;
    }

    public String getType() {
        return type;
    }

    public String getRegistration() {
        return registration;
    }

    public String getIn() {
        return in;
    }

    public double getAboard() {
        return aboard;
    }

    public int getFatalities() {
        return fatalities;
    }

    public int getGround() {
        return ground;
    }

    public int getSurvivors() {
        return survivors;
    }

    public double getSurvivalRate() {
        return survivalRate;
    }

    public String getSummary() {
        return summary;
    }

    @Override
    public String toString() {
        return "PlaneCrash " +
                "date=" + date +
                ", time=" + time +
                ", location='" + location + '\'' +
                ", operator='" + operator + '\'' +
                ", flight='" + flight + '\'' +
                ", route='" + route + '\'' +
                ", type='" + type + '\'' +
                ", registration='" + registration + '\'' +
                ", in='" + in + '\'' +
                ", aboard=" + aboard +
                ", fatalities=" + fatalities +
                ", ground=" + ground +
                ", survivors=" + survivors +
                ", survivalRate=" + survivalRate +
                ", summary='" + summary + '\'' +
                '}';
    }

    public static DateTimeFormatter getDateFormatter() {
        return DATE_FORMATTER;
    }

    public static DateTimeFormatter getTimeFormatter() {
        return TIME_FORMATTER;
    }

    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("dd/MM/yyyy");
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HH:mm");
}
