package az.edu.ada.ppfinal;

import az.edu.ada.ppfinal.cmd.CmdChoice;
import az.edu.ada.ppfinal.csv.CsvFile;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Paths;
import java.util.Objects;

public class PPFinal {
    public static void main(String[] args) throws IOException, URISyntaxException {
        CsvFile file = new CsvFile(Paths.get(Objects.requireNonNull(PPFinal.class.getClassLoader().getResource("table.csv")).toURI()));
        CmdChoice choice = new CmdChoice(file);

        choice.run();
    }
}
